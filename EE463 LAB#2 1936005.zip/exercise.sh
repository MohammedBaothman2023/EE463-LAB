if  [ `expr index "$1" 1*` -ne 0 ]
then
   echo "Symbol is not required"
else
   echo "* is required"
fi
